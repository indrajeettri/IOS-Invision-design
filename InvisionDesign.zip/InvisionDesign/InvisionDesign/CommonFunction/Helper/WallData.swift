//
//  WallData.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class WallData{

   var imageProfile : UIImage?
   var imagePost : UIImage?
   var name : String?
   var wallComment : String?
    
    
    var checkList : String?
    var checkImage : UIImage?
    
    var cellIdentifire : String?
   
   init(_ _imageProfile : UIImage?,_ _imagePost: UIImage? , _ _name: String , _ _wallPost : String? , _ _cellIdentifire : String? , _ _checkImage : UIImage, _ _checkList : String?) {
       imageProfile = _imageProfile
       imagePost = _imagePost
       name = _name
       wallComment = _wallPost
       
       checkList = _checkList
       checkImage = _checkImage
       
       
       cellIdentifire = _cellIdentifire
   }
   class func getArray() -> [WallData] {
       var array = [WallData]() 
       let image1 = #imageLiteral(resourceName: "imagePerson")
       let image2 = #imageLiteral(resourceName: "professional-laurete-in-marketing")
       let image3 = #imageLiteral(resourceName: "check")
       
       
       
    array = [WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","SearchBarCellTableViewCell", image3 , "check It"),
             WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 , "indrajeet"),
             WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
               WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
                 WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
                   WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
                     WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
                       WallData.init(image1, image2, "abhishek_Mattu","I recently got into AC/DC discography and it's so f***g great. £acdc £hardrock £music","wallTableViewCell", image3 ,"Indrajeet"),
    
    
    ]
                                                                                                                                                                                                                                                                                                                                                                                    
    
              
       return array
   }

}
