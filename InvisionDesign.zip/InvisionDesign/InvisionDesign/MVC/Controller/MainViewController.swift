//
//  MainViewController.swift
//  InvisionDesign
//
//  Created by Interns on 11/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBAction func buttonNext(_ sender: Any) {
        dothis1()
    }
    @IBOutlet weak var signInButton: UIButton!
    @IBAction func signInAction(_ sender: Any) {
          dothis()
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()

       // labelSignin.isUserInteractionEnabled = true
    }
    func dothis()  {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "SignViewViewController") as? SignViewViewController
            else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func dothis1()  {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as? LoginViewController
            else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
   
    @IBOutlet weak var labelSignin: UILabel!
    
        
    
}
