//
//  WallViewController.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class WallViewController: UIViewController {

    @IBAction func buttonBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    private var items: [WallData]?
    override func viewDidLoad() {
        super.viewDidLoad()
            items = WallData.getArray()
    }

}


extension WallViewController : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: items?[indexPath.row].cellIdentifire ?? "cellIdentifire", for: indexPath)
               if let cell1 = cell as? SearchBarCellTableViewCell{
                   cell1.item = items?[indexPath.row]
                   return cell1
               }
               else if let cell2 = cell as? wallTableViewCell {
                   cell2.item = items?[indexPath.row]
                   return cell2
                    
    }
    return cell
    
}
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0{
            return 60
        }
        else {
            return 400
        }
    }
}
