//
//  SignViewViewController.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class SignViewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        buttonNext.layer.cornerRadius = buttonNext.frame.size.width / 2
      
    }
    
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var buttonNext: UIButton!
    
  
    @IBAction func buttonNextAction(_ sender: Any) {
        dothis()
    }
    func dothis() {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "VarificationViewController") as? VarificationViewController
                   else{
                   return
               }
               self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func backButtonAction(_ sender: Any) {
      
                     self.navigationController?.popViewController(animated: true)
    }
}
