//
//  VarificationViewController.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class VarificationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        buttonNextOutlet.layer.cornerRadius = buttonNextOutlet.frame.size.width / 2
    }
    @IBAction func buttonNext(_ sender: Any) {
        dothis()
    }
    
    @IBAction func buttonBack(_ sender: Any) {
   self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBOutlet weak var buttonNextOutlet: UIButton!
    func dothis()  {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "CreatePassViewController") as? CreatePassViewController
            else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
   

}
