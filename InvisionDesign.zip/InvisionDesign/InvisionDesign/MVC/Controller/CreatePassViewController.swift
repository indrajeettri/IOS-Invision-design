//
//  CreatePassViewController.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class CreatePassViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

           buttonnextoutlet.layer.cornerRadius = buttonnextoutlet.frame.size.width / 2
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func buttonNext(_ sender: Any) {
        dothis()
    }
    func dothis()  {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "WelcomePage") as? WelcomePage
            else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBOutlet weak var buttonnextoutlet: UIButton!
    
}
