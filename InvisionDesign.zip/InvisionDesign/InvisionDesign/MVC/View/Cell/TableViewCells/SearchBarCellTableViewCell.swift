//
//  SearchBarCellTableViewCell.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class SearchBarCellTableViewCell: UITableViewCell {

    @IBOutlet weak var imageChek: UIImageView!
    
    @IBOutlet weak var lableCheckIt: UILabel!
    var item: WallData? {
        didSet{
            lableCheckIt.text = item?.checkList
           imageChek.image = item?.checkImage
            
        }
    }
    
}
