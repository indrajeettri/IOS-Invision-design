//
//  wallTableViewCell.swift
//  InvisionDesign
//
//  Created by Interns on 12/02/20.
//  Copyright © 2020 Interns. All rights reserved.
//

import UIKit

class wallTableViewCell: UITableViewCell {

    @IBOutlet weak var imageProfile: UIImageView!
    @IBOutlet weak var lableUserName: UILabel!
    @IBOutlet weak var lableComments: UILabel!
    @IBOutlet weak var imageWallPaper: UIImageView!
    
    var item: WallData? {
        didSet{
            lableUserName.text = item?.name
            lableComments.text = item?.wallComment
            imageProfile.image = item?.imageProfile
            imageWallPaper.image = item?.imagePost
        }
    }
}
